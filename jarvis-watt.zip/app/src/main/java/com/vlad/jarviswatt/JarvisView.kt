package com.vlad.jarviswatt

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Schermata HUD stile Jarvis: tutto disegnato a mano su Canvas. */
class JarvisView(context: Context) : View(context) {

    var lockHint = false

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val cyan = Color.parseColor("#00E5FF")
    private val amber = Color.parseColor("#FFB000")
    private val red = Color.parseColor("#FF5252")
    private val bg = Color.parseColor("#02060A")

    private fun Int.a(alpha: Int): Int = (this and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private var state = PowerState.EMPTY
    private var first = true
    private var dispWatts = 0f
    private var dispPercent = 0f
    private val history = FloatArray(60)
    private var lastSample = 0L
    private var rot = 0f
    private var pulse = 0f
    private var lastNs = 0L
    private var clock = ""
    private var clockAt = 0L
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(dp(10f), dp(8f)), 0f)
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thin = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
    private val rect = RectF()
    private val path = Path()
    private val fillPath = Path()
    private var scan: LinearGradient? = null
    private val band: Float get() = dp(140f)

    fun update(s: PowerState) {
        state = s
        val now = System.currentTimeMillis()
        if (first) {
            first = false
            history.fill(s.watts)
            lastSample = now
            return
        }
        if (now - lastSample >= 1000) {
            lastSample = now
            System.arraycopy(history, 1, history, 0, history.size - 1)
            history[history.size - 1] = s.watts
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        scan = LinearGradient(
            0f, 0f, 0f, band,
            intArrayOf(0, cyan.a(30), 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun label(
        c: Canvas, s: String, x: Float, y: Float, sizeDp: Float,
        color: Int, align: Paint.Align, spacing: Float = 0.2f
    ) {
        txt.typeface = mono
        txt.textSize = dp(sizeDp)
        txt.color = color
        txt.textAlign = align
        txt.letterSpacing = spacing
        txt.clearShadowLayer()
        c.drawText(s, x, y, txt)
    }

    private fun brackets(c: Canvas, l: Float, t: Float, r: Float, b: Float, len: Float) {
        c.drawLine(l, t, l + len, t, stroke); c.drawLine(l, t, l, t + len, stroke)
        c.drawLine(r, t, r - len, t, stroke); c.drawLine(r, t, r, t + len, stroke)
        c.drawLine(l, b, l + len, b, stroke); c.drawLine(l, b, l, b - len, stroke)
        c.drawLine(r, b, r - len, b, stroke); c.drawLine(r, b, r, b - len, stroke)
    }

    private fun panel(
        c: Canvas, l: Float, t: Float, w: Float, h: Float,
        name: String, value: String, unit: String, col: Int
    ) {
        fill.color = col.a(16)
        c.drawRect(l, t, l + w, t + h, fill)
        stroke.clearShadowLayer()
        stroke.strokeWidth = dp(1.5f)
        stroke.color = col.a(200)
        brackets(c, l, t, l + w, t + h, dp(10f))
        label(c, name, l + dp(12f), t + dp(18f), 9f, col.a(190), Paint.Align.LEFT, 0.25f)

        txt.typeface = thin
        txt.textAlign = Paint.Align.LEFT
        txt.letterSpacing = 0f
        txt.textSize = dp(26f)
        txt.color = Color.WHITE
        txt.setShadowLayer(dp(8f), 0f, 0f, col)
        val baseY = t + h - dp(12f)
        c.drawText(value, l + dp(12f), baseY, txt)
        if (unit.isNotEmpty()) {
            val vw = txt.measureText(value)
            txt.clearShadowLayer()
            txt.textSize = dp(12f)
            txt.color = col
            c.drawText(unit, l + dp(12f) + vw + dp(4f), baseY, txt)
        }
        txt.clearShadowLayer()
    }

    override fun onDraw(c: Canvas) {
        val nowNs = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((nowNs - lastNs) / 1e9f).coerceAtMost(0.1f)
        lastNs = nowNs

        val s = state
        dispWatts += (s.watts - dispWatts) * min(1f, dt * 4f)
        dispPercent += (s.percent - dispPercent) * min(1f, dt * 2.5f)
        rot = (rot + (8f + dispWatts * 1.2f) * dt) % 360f
        pulse = (pulse + dt * 0.5f) % 1f

        val nowMs = System.currentTimeMillis()
        if (nowMs - clockAt > 1000) {
            clockAt = nowMs
            clock = timeFmt.format(Date(nowMs))
        }

        val col = when {
            s.tempC >= 45f -> red
            s.tempC >= 40f -> amber
            else -> cyan
        }
        val w = width.toFloat()
        val h = height.toFloat()
        val m = dp(20f)

        c.drawColor(bg)

        // ---- griglia di sfondo + linea di scansione
        stroke.clearShadowLayer()
        stroke.strokeCap = Paint.Cap.BUTT
        stroke.strokeWidth = 1f
        stroke.color = col.a(12)
        val step = dp(36f)
        var gx = 0f
        while (gx < w) { c.drawLine(gx, 0f, gx, h, stroke); gx += step }
        var gy = 0f
        while (gy < h) { c.drawLine(0f, gy, w, gy, stroke); gy += step }

        scan?.let {
            val sy = ((nowNs / 1e9f * 0.10f) % 1f) * (h + band) - band
            c.save()
            c.translate(0f, sy)
            fill.shader = it
            c.drawRect(0f, 0f, w, band, fill)
            fill.shader = null
            c.restore()
        }

        // ---- angoli dello schermo
        stroke.strokeWidth = dp(2f)
        stroke.color = col.a(150)
        brackets(c, dp(10f), dp(10f), w - dp(10f), h - dp(10f), dp(26f))

        // ---- intestazione
        val topPad = dp(52f)
        label(c, "LINK:${s.plug}", m, topPad, 10f, col.a(200), Paint.Align.LEFT, 0.15f)
        label(c, "POWER CORE", w / 2f, topPad, 11f, col, Paint.Align.CENTER, 0.3f)
        label(c, clock, w - m, topPad, 11f, col.a(200), Paint.Align.RIGHT, 0.15f)
        stroke.strokeWidth = dp(1f)
        stroke.color = col.a(90)
        c.drawLine(m, topPad + dp(10f), w - m, topPad + dp(10f), stroke)

        // ---- nucleo: anelli
        val r = min(w * 0.34f, h * 0.17f)
        val cx = w / 2f
        val cy = topPad + dp(44f) + r * 1.2f

        if (s.charging) {
            stroke.strokeWidth = dp(2f)
            stroke.color = col.a(((1f - pulse) * 110f).toInt())
            c.drawCircle(cx, cy, r * 0.62f + pulse * r * 0.30f, stroke)
        }

        stroke.strokeWidth = dp(1f)
        stroke.color = col.a(70)
        c.drawCircle(cx, cy, r * 1.20f, stroke)

        // archi esterni rotanti
        stroke.strokeWidth = dp(3f)
        stroke.color = col.a(220)
        stroke.setShadowLayer(dp(8f), 0f, 0f, col)
        rect.set(cx - r * 1.12f, cy - r * 1.12f, cx + r * 1.12f, cy + r * 1.12f)
        for (k in 0..2) c.drawArc(rect, rot + k * 120f, 55f, false, stroke)
        stroke.clearShadowLayer()

        // tacche che girano al contrario
        c.save()
        c.rotate(-rot * 0.5f, cx, cy)
        stroke.strokeWidth = dp(1.5f)
        stroke.color = col.a(140)
        for (i in 0 until 72) {
            val len = if (i % 6 == 0) dp(12f) else dp(6f)
            c.drawLine(cx, cy - r * 1.03f, cx, cy - r * 1.03f + len, stroke)
            c.rotate(5f, cx, cy)
        }
        c.restore()

        // anello di avanzamento batteria
        val rp = r * 0.84f
        rect.set(cx - rp, cy - rp, cx + rp, cy + rp)
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeWidth = dp(12f)
        stroke.color = col.a(36)
        c.drawArc(rect, 0f, 360f, false, stroke)
        val sweep = dispPercent * 3.6f
        if (sweep > 1f) {
            stroke.color = col
            stroke.setShadowLayer(dp(16f), 0f, 0f, col)
            c.drawArc(rect, -90f, sweep, false, stroke)
            stroke.clearShadowLayer()
            val ang = (-90f + sweep) * PI.toFloat() / 180f
            fill.color = Color.WHITE
            fill.setShadowLayer(dp(10f), 0f, 0f, col)
            c.drawCircle(cx + rp * cos(ang), cy + rp * sin(ang), dp(5f), fill)
            fill.clearShadowLayer()
        }
        stroke.strokeCap = Paint.Cap.BUTT

        // anello tratteggiato interno
        c.save()
        c.rotate(rot * 2f, cx, cy)
        dash.strokeWidth = dp(1.5f)
        dash.color = col.a(120)
        c.drawCircle(cx, cy, r * 0.66f, dash)
        c.restore()
        stroke.strokeWidth = dp(1f)
        stroke.color = col.a(60)
        c.drawCircle(cx, cy, r * 0.60f, stroke)

        // percentuale al centro
        label(c, "BATTERY", cx, cy - dp(40f), 9f, col.a(200), Paint.Align.CENTER, 0.3f)
        val pct = dispPercent.roundToInt().toString()
        txt.typeface = thin
        txt.letterSpacing = 0f
        txt.textAlign = Paint.Align.LEFT
        txt.textSize = dp(64f)
        val pw = txt.measureText(pct)
        txt.textSize = dp(22f)
        val sw = txt.measureText("%")
        val startX = cx - (pw + sw + dp(2f)) / 2f
        txt.textSize = dp(64f)
        txt.color = Color.WHITE
        txt.setShadowLayer(dp(14f), 0f, 0f, col)
        c.drawText(pct, startX, cy + dp(18f), txt)
        txt.textSize = dp(22f)
        txt.color = col
        c.drawText("%", startX + pw + dp(2f), cy + dp(18f), txt)
        txt.clearShadowLayer()
        label(c, s.mode(), cx, cy + dp(42f), 8.5f, col, Paint.Align.CENTER, 0.12f)

        // ---- watt
        val ringBottom = cy + r * 1.2f
        val labelY = ringBottom + dp(34f)
        label(
            c, if (s.charging) "POWER INPUT" else "POWER DRAW",
            cx, labelY, 11f, col.a(210), Paint.Align.CENTER, 0.35f
        )
        val wTxt = String.format(Locale.US, "%.1f", dispWatts)
        txt.typeface = thin
        txt.letterSpacing = 0f
        txt.textAlign = Paint.Align.LEFT
        txt.textSize = dp(76f)
        val bw = txt.measureText(wTxt)
        txt.textSize = dp(28f)
        val uw = txt.measureText("W")
        val wx = cx - (bw + dp(8f) + uw) / 2f
        val wy = labelY + dp(72f)
        txt.textSize = dp(76f)
        txt.color = Color.WHITE
        txt.setShadowLayer(dp(18f), 0f, 0f, col)
        c.drawText(wTxt, wx, wy, txt)
        txt.textSize = dp(28f)
        txt.color = col
        c.drawText("W", wx + bw + dp(8f), wy, txt)
        txt.clearShadowLayer()

        // ---- pannelli
        val pTop = wy + dp(26f)
        val pw2 = (w - 2 * m - dp(12f)) / 2f
        val ph = dp(62f)
        val gap = dp(10f)
        val etaVal: String
        val etaUnit: String
        when {
            s.full -> { etaVal = "FULL"; etaUnit = "" }
            s.charging && s.etaMin >= 60 -> {
                etaVal = "${s.etaMin / 60}h " + String.format(Locale.US, "%02d", s.etaMin % 60)
                etaUnit = ""
            }
            s.charging && s.etaMin >= 0 -> { etaVal = "${s.etaMin}"; etaUnit = "min" }
            else -> { etaVal = "--"; etaUnit = "" }
        }
        panel(c, m, pTop, pw2, ph, "VOLTAGE", String.format(Locale.US, "%.2f", s.voltage), "V", col)
        panel(c, m + pw2 + dp(12f), pTop, pw2, ph, "CURRENT", String.format(Locale.US, "%.2f", s.currentA), "A", col)
        panel(c, m, pTop + ph + gap, pw2, ph, "TEMP", String.format(Locale.US, "%.1f", s.tempC), "°C", col)
        panel(c, m + pw2 + dp(12f), pTop + ph + gap, pw2, ph, "ETA", etaVal, etaUnit, col)

        // ---- grafico watt
        val sTop = pTop + 2 * ph + gap + dp(34f)
        val sBottom = max(sTop + dp(40f), min(h - dp(52f), sTop + dp(100f)))
        val maxV = max(history.maxOrNull() ?: 0f, 10f) * 1.15f
        label(c, "POWER FLOW // 60s", m, sTop - dp(10f), 9f, col.a(190), Paint.Align.LEFT, 0.25f)
        label(
            c, String.format(Locale.US, "MAX %.0fW", maxV / 1.15f),
            w - m, sTop - dp(10f), 9f, col.a(190), Paint.Align.RIGHT, 0.2f
        )
        stroke.strokeWidth = dp(1f)
        stroke.color = col.a(40)
        for (k in 0..2) {
            val ly = sTop + k * (sBottom - sTop) / 2f
            c.drawLine(m, ly, w - m, ly, stroke)
        }
        path.reset()
        fillPath.reset()
        var lastX = m
        var lastY = sBottom
        for (i in history.indices) {
            val x = m + i * (w - 2 * m) / (history.size - 1)
            val y = sBottom - (history[i] / maxV).coerceIn(0f, 1f) * (sBottom - sTop)
            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, sBottom)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            lastX = x
            lastY = y
        }
        fillPath.lineTo(w - m, sBottom)
        fillPath.close()
        fill.color = col.a(28)
        c.drawPath(fillPath, fill)
        stroke.strokeWidth = dp(2f)
        stroke.color = col
        stroke.setShadowLayer(dp(8f), 0f, 0f, col)
        c.drawPath(path, stroke)
        stroke.clearShadowLayer()
        fill.color = Color.WHITE
        c.drawCircle(lastX, lastY, dp(3.5f), fill)

        // ---- suggerimento in modalita' blocco
        if (lockHint) {
            val a = (110 + sin(pulse * 2f * PI.toFloat()) * 50f).toInt()
            label(c, "TAP TO UNLOCK", cx, h - dp(24f), 9f, col.a(a), Paint.Align.CENTER, 0.3f)
        }

        postInvalidateOnAnimation()
    }
}
