package com.vlad.jarviswatt

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import java.util.Locale
import kotlin.math.roundToInt

class PowerService : Service() {

    companion object {
        const val CH_CHARGE = "charge"
        const val CH_IDLE = "idle"
        const val CH_LOCK = "lock"
        const val ID_STATUS = 1
        const val ID_LOCK = 2
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1500)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    postLockScreenIntent()
                    refresh()
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    nm.cancel(ID_LOCK)
                    refresh()
                }
                Intent.ACTION_SCREEN_OFF -> launchOnScreenOff()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(
            NotificationChannel(CH_CHARGE, "Watt in carica", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_IDLE, "Monitor in attesa", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_LOCK, "Schermata di ricarica", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildStatus(BatteryReader.read(this))
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_STATUS, n)
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
    }

    private fun refresh() {
        nm.notify(ID_STATUS, buildStatus(BatteryReader.read(this)))
    }

    private fun buildStatus(s: PowerState): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val b = if (s.charging) {
            val eta = if (s.etaMin >= 0) " · ${s.etaMin} min" else ""
            Notification.Builder(this, CH_CHARGE)
                .setSmallIcon(numberIcon(s.watts))
                .setContentTitle(String.format(Locale.US, "%.1f W · %s", s.watts, s.mode()))
                .setContentText(
                    String.format(Locale.US, "%.2f V · %.2f A · %.1f °C", s.voltage, s.currentA, s.tempC) + eta
                )
        } else {
            Notification.Builder(this, CH_IDLE)
                .setSmallIcon(R.drawable.ic_bolt)
                .setContentTitle("Jarvis Watt")
                .setContentText(if (s.full) "Batteria carica" else "In attesa del caricatore · ${s.percent}%")
        }

        return b.setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    /** Disegna i watt come icona monocromatica per la barra di stato. */
    private fun numberIcon(watts: Float): Icon {
        val t = if (watts >= 9.95f) watts.roundToInt().toString()
        else String.format(Locale.US, "%.1f", watts)
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            textSize = size * 0.9f
        }
        val w = p.measureText(t)
        if (w > size) p.textSize = p.textSize * size / w
        val fm = p.fontMetrics
        c.drawText(t, size / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, p)
        return Icon.createWithBitmap(bmp)
    }

    /** Collegando il caricatore a telefono bloccato / schermo spento: apre il monitor sopra il blocco. */
    private fun postLockScreenIntent() {
        val km = getSystemService(KeyguardManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        if (!km.isKeyguardLocked && pm.isInteractive) return

        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_LOCK, true)
        val pi = PendingIntent.getActivity(
            this, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH_LOCK)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Caricatore collegato")
            .setContentText("Tocca per aprire il monitor")
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
            .setTimeoutAfter(20000)
            .build()
        nm.notify(ID_LOCK, n)
    }

    /** Se si blocca il telefono mentre e' in carica, prepara il monitor senza riaccendere lo schermo. */
    private fun launchOnScreenOff() {
        val s = BatteryReader.read(this)
        if (!s.plugged) return
        if (!Settings.canDrawOverlays(this)) return
        handler.postDelayed({
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(MainActivity.EXTRA_LOCK, true)
                        .putExtra(MainActivity.EXTRA_NO_WAKE, true)
                )
            } catch (_: Exception) {
            }
        }, 700)
    }
}
