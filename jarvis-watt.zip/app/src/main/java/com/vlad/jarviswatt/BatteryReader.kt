package com.vlad.jarviswatt

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

data class PowerState(
    val percent: Int,
    val voltage: Float,
    val tempC: Float,
    val currentA: Float,
    val watts: Float,
    val charging: Boolean,
    val full: Boolean,
    val plugged: Boolean,
    val plug: String,
    val etaMin: Int
) {
    fun mode(): String = when {
        full -> "BATTERY FULL"
        charging && watts >= 25f -> "SUPER FAST CHARGING"
        charging && watts >= 10f -> "FAST CHARGING"
        charging -> "CHARGING"
        plugged -> "CONNECTED"
        else -> "ON BATTERY"
    }

    companion object {
        val EMPTY = PowerState(0, 0f, 0f, 0f, 0f, false, false, false, "NONE", -1)
    }
}

object BatteryReader {

    fun read(ctx: Context): PowerState {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugType = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0

        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val raw = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // Di solito e' in microampere, su alcuni telefoni in milliampere.
        val ma = when {
            raw == Long.MIN_VALUE || raw == 0L -> 0f
            abs(raw) < 20000L -> abs(raw).toFloat()
            else -> abs(raw) / 1000f
        }

        val volts = mv / 1000f
        val amps = ma / 1000f
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val full = status == BatteryManager.BATTERY_STATUS_FULL
        val plugged = plugType != 0
        val plug = when {
            (plugType and BatteryManager.BATTERY_PLUGGED_WIRELESS) != 0 -> "WIRELESS"
            (plugType and BatteryManager.BATTERY_PLUGGED_AC) != 0 -> "AC"
            (plugType and BatteryManager.BATTERY_PLUGGED_USB) != 0 -> "USB"
            plugged -> "DOCK"
            else -> "NONE"
        }

        var eta = -1
        if (charging) {
            val ms = bm.computeChargeTimeRemaining()
            if (ms > 0L) {
                eta = (ms / 60000L).toInt()
            } else if (ma > 50f && pct in 1..99) {
                val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
                if (counter > 0L && counter != Long.MIN_VALUE) {
                    val fullUah = counter * 100f / pct
                    eta = ((fullUah - counter) / 1000f / ma * 60f).toInt()
                }
            }
        }

        return PowerState(pct, volts, temp, amps, volts * amps, charging, full, plugged, plug, eta)
    }
}
