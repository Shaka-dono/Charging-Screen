package com.vlad.jarviswatt

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        const val EXTRA_LOCK = "lock"
        const val EXTRA_NO_WAKE = "nowake"
    }

    private lateinit var hud: JarvisView
    private val handler = Handler(Looper.getMainLooper())
    private var lockMode = false

    private val tick = object : Runnable {
        override fun run() {
            hud.update(BatteryReader.read(this@MainActivity))
            handler.postDelayed(this, 1000)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!lockMode) return
            when (intent.action) {
                Intent.ACTION_USER_PRESENT, Intent.ACTION_POWER_DISCONNECTED -> finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(!intent.getBooleanExtra(EXTRA_NO_WAKE, false))

        hud = JarvisView(this)
        setContentView(hud)
        applyIntent(intent)
        hud.setOnClickListener { if (lockMode) dismissLock() }
        hideBars()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }

        startForegroundService(Intent(this, PowerService::class.java))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        setTurnScreenOn(!intent.getBooleanExtra(EXTRA_NO_WAKE, false))
        applyIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        hideBars()
        handler.removeCallbacks(tick)
        handler.post(tick)
        setupStep()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
    }

    private fun applyIntent(i: Intent?) {
        val km = getSystemService(KeyguardManager::class.java)
        lockMode = (i?.getBooleanExtra(EXTRA_LOCK, false) == true) || km.isKeyguardLocked
        hud.lockHint = lockMode
    }

    private fun dismissLock() {
        val km = getSystemService(KeyguardManager::class.java)
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                finish()
            }
        })
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    /** Chiede i permessi uno alla volta, ogni passo una sola volta. */
    private fun setupStep() {
        if (lockMode) return
        val p = getSharedPreferences("setup", Context.MODE_PRIVATE)
        val nm = getSystemService(NotificationManager::class.java)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !p.getBoolean("n", false)
        ) {
            p.edit().putBoolean("n", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }

        if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent() && !p.getBoolean("f", false)) {
            p.edit().putBoolean("f", true).apply()
            Toast.makeText(this, "Attiva «Notifiche a schermo intero» per mostrare il monitor a telefono bloccato", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            return
        }

        if (!Settings.canDrawOverlays(this) && !p.getBoolean("o", false)) {
            p.edit().putBoolean("o", true).apply()
            Toast.makeText(this, "Attiva «Mostra sopra altre app» per far comparire il monitor quando blocchi lo schermo in carica", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }
}
